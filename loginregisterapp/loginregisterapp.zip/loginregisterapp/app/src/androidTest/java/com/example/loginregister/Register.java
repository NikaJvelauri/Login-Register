package com.example.loginregister;

public class Register {
}
